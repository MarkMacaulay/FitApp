﻿#define AZURE


using FitAppApp.ViewModel;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace FitAppApp.UWP.Views
{
    public sealed partial class Login : Page
    {
        // Button signInButton, notNowButton;
        // LinearLayout signingInPanel;
        public Login()
        {
            this.InitializeComponent();
            DataContext = new LoginViewModel();

        }

        private void ImageBrush_ImageFailed(object sender, ExceptionRoutedEventArgs e)
        {

        }

        private void btnNotNow_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(MainPivot), null);
        }
    }
}
