﻿namespace FitAppApp.Interfaces
{
	public interface IBaseDataObject
    {
        string Id { get; set; }
    }
}
