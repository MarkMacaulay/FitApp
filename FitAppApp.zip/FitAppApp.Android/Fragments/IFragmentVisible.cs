namespace FitAppApp.Droid
{
    interface IFragmentVisible
    {
        void BecameVisible();
    }
}